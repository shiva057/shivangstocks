// Shivang Stocks Researcher — Production Service Worker (v11.0 PWABuilder Ready)
const CACHE_NAME = 'shivang-stocks-pwa-v15-1-sr';
const RUNTIME_API_CACHE = 'shivang-stocks-live-api-v14';

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/icon-maskable-512.png',
  '/screenshot-mobile.png',
  '/screenshot-desktop.png'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_URLS).catch((err) => {
        console.warn('[SW] Partial precache warning:', err);
      });
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== RUNTIME_API_CACHE) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Handle messages from the client (e.g., SKIP_WAITING)
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

// Fetch handler:
// - Navigation requests: Network-first with immediate fallback to cached /index.html (guarantees 100% offline launch for PWABuilder & TWA)
// - Live stock API / font requests: Network-first with runtime cache fallback
// - Static same-origin assets: Stale-While-Revalidate
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // 1. HTML Navigation requests (Offline App Shell support)
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(
      fetch(req)
        .then((networkResp) => {
          if (networkResp && networkResp.ok) {
            const copy = networkResp.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', copy));
          }
          return networkResp;
        })
        .catch(async () => {
          const cache = await caches.open(CACHE_NAME);
          return (
            (await cache.match(req, { ignoreSearch: true })) ||
            (await cache.match('/index.html')) ||
            (await cache.match('/'))
          );
        })
    );
    return;
  }

  // 2. Same-origin static assets (icons, manifest, screenshots, app shell)
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req, { ignoreSearch: true }).then((cachedResp) => {
        const fetchPromise = fetch(req)
          .then((networkResp) => {
            if (networkResp && networkResp.ok) {
              const copy = networkResp.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
            }
            return networkResp;
          })
          .catch(() => cachedResp);
        return cachedResp || fetchPromise;
      })
    );
    return;
  }

  // 3. Cross-origin live market APIs & Google Fonts (Network-first with cache fallback)
  event.respondWith(
    fetch(req)
      .then((networkResp) => {
        if (networkResp && (networkResp.ok || networkResp.type === 'opaque')) {
          const copy = networkResp.clone();
          caches.open(RUNTIME_API_CACHE).then((cache) => cache.put(req, copy));
        }
        return networkResp;
      })
      .catch(() => caches.match(req))
  );
});

// Background Sync support for PWABuilder capability checks
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-watchlist-quotes') {
    event.waitUntil(Promise.resolve());
  }
});

// Periodic Background Sync support for PWABuilder capability checks
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'refresh-nse-bse-quotes') {
    event.waitUntil(Promise.resolve());
  }
});
